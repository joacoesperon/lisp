# Practica Lisp Laberinto

# Preguntas Profesor

se puede usar cosas que no esten en los apuntes?
1.  dotimes
2.  if
3.  make-array
4.  nth